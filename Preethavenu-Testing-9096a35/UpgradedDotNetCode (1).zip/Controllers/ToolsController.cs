using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace ProjectName.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ToolsController : ControllerBase
    {
        [HttpGet]
        public IActionResult GetAllTools()
        {
            var tools = new List<string> { "Tool1", "Tool2", "Tool3" };
            return Ok(tools);
        }

        [HttpPut]
        public IActionResult UpdateAgentWithoutToolsParameters([FromBody] AgentUpdateModel model)
        {
            if (ModelState.IsValid)
            {
                // Update logic here
                return Ok();
            }
            return BadRequest(ModelState);
        }
    }

    public class AgentUpdateModel
    {
        public int LevelId { get; set; }
        public string AgentDetail { get; set; }
        public string Name { get; set; }
        public int ModelRef { get; set; }
        public string Role { get; set; }
        public string Goal { get; set; }
        public string Backstory { get; set; }
        public string Description { get; set; }
        public string ExpectedOutput { get; set; }
    }
}